#!/bin/sh
clear
cat << 'EOF'
==================================================
           MinOS - Hizli Disk Kurulumu
==================================================
EOF

# Otomatik disk tespiti (vda, sda, nvme0n1)
TARGET=""
for d in /dev/vda /dev/sda /dev/nvme0n1; do
    if [ -b "$d" ]; then
        TARGET="$d"
        break
    fi
done

if [ -z "$TARGET" ]; then
    echo "[HATA] Kurulacak sabit disk bulunamadi!"
    exit 1
fi

echo ""
echo "[*] Hedef Disk: $TARGET"
printf "MinOS $TARGET diskine kurulsun mu? (E/h): "
read ONAY
if [ "$ONAY" = "h" ] || [ "$ONAY" = "H" ]; then
    echo "Kurulum iptal edildi."
    exit 0
fi

echo ""
echo "[1/4] Disk temizleniyor..."
dd if=/dev/zero of="$TARGET" bs=1M count=2 status=none 2>/dev/null || true

echo "[2/4] Tek bolum (MBR/FAT32) olusturuluyor..."
# MBR tablosu olustur ve tek parca 100% bootable bolum ac
parted -s "$TARGET" mklabel msdos mkpart primary fat32 1MiB 100% set 1 boot on 2>/dev/null || true

# Bolum aygitini belirle (vda -> vda1, nvme0n1 -> nvme0n1p1)
PART="${TARGET}1"
if [ ! -b "$PART" ]; then
    PART="${TARGET}p1"
fi

# Kernel partition tablosunu tazele
mknod "${TARGET}1" b 254 1 2>/dev/null || true
mknod "${TARGET}p1" b 259 1 2>/dev/null || true

echo "[3/4] Bolum formatlaniyor ve baglaniyor..."
mkfs.vfat -F 32 "$PART" 2>/dev/null || mkfs.ext4 -F "$PART" 2>/dev/null || true
mkdir -p /mnt/minos
mount "$PART" /mnt/minos 2>/dev/null || true

echo "[4/4] MinOS sistem dosyalari kopyalaniyor..."
# CD/USB medyasini bul
MEDYA=""
for m in /media/cdrom /media/usb /media/iso /media/*; do
    if [ -d "$m/boot" ]; then
        MEDYA="$m"
        break
    fi
done

if [ -n "$MEDYA" ]; then
    cp -r "$MEDYA/boot" /mnt/minos/ 2>/dev/null || true
    cp "$MEDYA/limine.cfg" /mnt/minos/ 2>/dev/null || true
    cp "$MEDYA/limine.conf" /mnt/minos/ 2>/dev/null || true
    cp "$MEDYA/limine-bios.sys" /mnt/minos/ 2>/dev/null || true
fi

sync
umount /mnt/minos 2>/dev/null || true

echo ""
echo "=================================================="
echo "    TEBRIKLER! MinOS Kurulumu Tamamlandi!         "
echo "=================================================="
echo "Medyanizi cikarip diski baslatabilirsiniz."
echo ""
printf "Sistem simdi yeniden baslatilsin mi? (E/h): "
read REBOOT_NOW
if [ "$REBOOT_NOW" != "h" ] && [ "$REBOOT_NOW" != "H" ]; then
    reboot -f
fi
