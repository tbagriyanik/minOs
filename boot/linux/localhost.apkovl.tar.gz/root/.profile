#!/bin/sh
clear
cat << 'EOF'
==================================================
           MinOS - Hizli Disk Kurulumu
==================================================
EOF

# Otomatik disk tespiti (vda, sda, nvme0n1)
TARGET=""
for d in /dev/vda /dev/sda /dev/nvme0n1; do
    if [ -b "$d" ]; then
        TARGET="$d"
        break
    fi
done

if [ -z "$TARGET" ]; then
    echo "[HATA] Sistemde sabit disk bulunamadi!"
    exit 1
fi

echo ""
echo "[*] Hedef Disk Tespit Edildi: $TARGET"
echo ""
echo "[1/2] Yeni root parolasini belirleyin:"
passwd root

echo ""
echo "[2/2] MinOS $TARGET diskine kurulacak."
printf "Kurulumu baslatmak icin ENTER'a basin (Iptal: Ctrl+C)... "
read DUMMY

echo ""
echo "[*] $TARGET hazirlaniyor ve sistem yukleniyor..."
echo "--------------------------------------------------"

# setup-disk doğrudan sys modu ile formatlayıp kurar
ERASE_DISKS="$TARGET" setup-disk -m sys -s 0 "$TARGET"

echo ""
echo "=================================================="
echo "    TEBRIKLER! Kurulum Basariyla Tamamlandi!      "
echo "=================================================="
printf "Sistemi yeniden baslatmak icin ENTER'a basin... "
read DUMMY
reboot -f
