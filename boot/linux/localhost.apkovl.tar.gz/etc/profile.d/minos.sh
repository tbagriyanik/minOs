#!/bin/sh
clear
echo "=================================================="
echo "    MinOS Otomatik Kurulum Servisi Calisiyor...   "
echo "=================================================="

# 1. Hedef Diski Bul (/dev/vda veya /dev/sda)
TARGET=""
for d in /dev/vda /dev/sda /dev/nvme0n1 /dev/sdb; do
    if [ -b "$d" ]; then
        TARGET="$d"
        break
    fi
done

if [ -z "$TARGET" ]; then
    echo "[HATA] Disk bulunamadi!"
    sleep 3
    exit 1
fi

echo "[*] Hedef Disk: $TARGET"
echo "[1/4] Disk temizleniyor..."
dd if=/dev/zero of="$TARGET" bs=1M count=4 status=none 2>/dev/null || true

echo "[2/4] MBR ve FAT32 Bolumu Aciliyor..."
parted -s "$TARGET" mklabel msdos 2>/dev/null || true
parted -s "$TARGET" mkpart primary fat32 1MiB 100% 2>/dev/null || true
parted -s "$TARGET" set 1 boot on 2>/dev/null || true

# Bolum aygitini bul
PART="${TARGET}1"
if [ ! -b "$PART" ]; then
    PART="${TARGET}p1"
fi

# Aygit dugumunu olustur (kernel udev gecikmelerine karsi)
mknod "${TARGET}1" b 254 1 2>/dev/null || true
mknod "${TARGET}1" b 8 1 2>/dev/null || true

echo "[3/4] FAT32 Formatlaniyor..."
mkfs.vfat -F 32 "$PART" 2>/dev/null || mkfs.fat -F 32 "$PART" 2>/dev/null || mkfs.ext4 -F "$PART" 2>/dev/null || true

mkdir -p /mnt/minos
mount "$PART" /mnt/minos 2>/dev/null || mount -t vfat "$PART" /mnt/minos 2>/dev/null || true

echo "[4/4] MinOS ve Limine Dosyalari Kopyalaniyor..."
mkdir -p /mnt/minos/boot
# CD/USB medyasini bul
for m in /media/cdrom /media/usb /media/* /mnt/cdrom; do
    if [ -f "$m/boot/minos-kernel" ]; then
        cp "$m/boot/minos-kernel" /mnt/minos/boot/ 2>/dev/null || true
        cp "$m/boot/limine/limine.cfg" /mnt/minos/boot/ 2>/dev/null || true
        cp "$m/limine.cfg" /mnt/minos/ 2>/dev/null || true
        cp "$m/limine-bios.sys" /mnt/minos/ 2>/dev/null || true
        break
    fi
done

# Eger mount edilmediyse CD'yi doğrudan bağla
if [ ! -f /mnt/minos/boot/minos-kernel ]; then
    mkdir -p /tmp/cd
    mount /dev/cdrom /tmp/cd 2>/dev/null || mount /dev/sr0 /tmp/cd 2>/dev/null || true
    if [ -f /tmp/cd/boot/minos-kernel ]; then
        cp "/tmp/cd/boot/minos-kernel" /mnt/minos/boot/ 2>/dev/null || true
        cp "/tmp/cd/limine.cfg" /mnt/minos/ 2>/dev/null || true
        cp "/tmp/cd/limine-bios.sys" /mnt/minos/ 2>/dev/null || true
    fi
fi

sync
umount /mnt/minos 2>/dev/null || true

echo ""
echo "=================================================="
echo "    KURULUM TAMAMLANDI! (Disk Hazir)              "
echo "=================================================="
echo "Sistem yeniden baslatiliyor..."
sleep 2
reboot -f 2>/dev/null || poweroff -f
