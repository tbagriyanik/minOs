#!/bin/sh
clear
echo "=================================================="
echo "          MinOS / Linux Hizli Kurulum             "
echo "=================================================="
echo ""
exec /sbin/setup-alpine -q
